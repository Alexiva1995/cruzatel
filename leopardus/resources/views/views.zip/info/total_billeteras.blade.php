@extends('layouts.dashboard')

@section('content')

<div class="wrapper-md" style="padding: 15px;">
    <div class="col-md-12 buq">
        <h3>El total de todas las billeteras es: <b>{{$totalBilleteras}}</b></h3>
    </div>
</div>

@endsection