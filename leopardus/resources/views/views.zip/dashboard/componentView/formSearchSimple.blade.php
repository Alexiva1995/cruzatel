<div class="card bg-blue-dark text-white">
    {{-- <div class="card-header">
        <div class="card-title">
            
        </div>
    </div> --}}
    <div class="card-content">
        <div class="card-body">
            <form method="POST" action="{{ route($route) }}">
                <div class="row">
                    {{ csrf_field() }}
                    <div class="col-12 col-sm-6 col-md-8">
                        <label class="control-label " style="text-align: center; margin-top:4px;">{{$text}}</label>
                        <input class="form-control form-control-solid placeholder-no-fix" type="{{$type}}"
                            autocomplete="off" name="{{$name1}}" required style="background-color:f7f7f7;" />
                    </div>
                    <div class="col-12 text-center col-md-2" style="padding-left: 10px;">
                        <button class="btn btn-primary mt-2" type="submit" id="btn">Buscar</button>
                    </div>
                    @if ($volver)
                    <div class="col-12 text-center col-md-2" style="padding-left: 10px;">
                        <a class="btn btn-info mt-2" href="{{$ruta}}">
                            Limpiar
                        </a>
                    </div>
                    @endif
                </div>
            </form>
        </div>
    </div>
</div>