<!DOCTYPE html>

<html lang="en">

<head>

	<meta charset="UTF-8">

	<title>Document</title>

</head>

<body>

	<center><strong> ¡¡Bienvenido(a) a Emprende Network!! </strong></center>



	<span>Somos la primera Red Social para Emprendedores y Empresarios de América Latina. Nuestra misión es formar Empresarios de Clase Mundial, desarrollar Constructores de Equipo y juntos maximizar nuestro desempeño y resultados.</span><br>



	<span>¡Felicidades! Su registro a sido exitoso.</span><br>



	<span>Sus datos de cuenta son:</span><br>



	<ul>

		<li>Nombre de Usuario: {{ $data['username'] }}</li>

		<li>Contraseña: {{ $data['password'] }}</li>

		<li>Link para Acceder a Oficina Virtual: <a href="https://emprende.network/mioficina">https://emprende.network/mioficina</a></li>

		<li>Link para Zona de Miembros: <a href="https://emprende.network/privado/wp-login.php">https://emprende.network/privado/wp-login.php</a></li>

	</ul>



	<span>Cordialmente</span><br>



	<span>Administración Emprende Netword</span><br>



	<span>Calle 79 No. 30-37, Barrio Gaitán, Bogotá.</span><br>



	<span><a href="www.emprende.network">www.emprende.network</a></span>

</body>

</html>