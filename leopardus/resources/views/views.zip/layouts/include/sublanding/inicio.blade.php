<div class="card mb-3 no-border bg-trans d-flex justify-content-center border-0" style="height:400px">
    <div class="row no-gutters">
        <div class="col-md-12 d-flex align-items-center">
            <div class="card-body">
                <h1 class="text-white" style="font-weight: 900;">
                    <strong>En este momento en algun <br> lugar del mundo...</strong>
                </h1>
                <h5 class="text-white" style="font-weight: 600;">
                    <small>¡Un lider se está afiliando para impulsar la idea del otro!</small>
                </h5>
                {{-- <h3 style="color: #002a38; font-weight: 700;">
                    AL SIGUIENTE NIVEL
                </h3> --}}
                <a class="btn text-white pl-4 pr-4" href="javascript:;" style="background: #3A58A2; border-radius: 15px">
                    <strong>¡AFILIATE AHORA MISMO!</strong>
                </a>
            </div>
        </div>
    </div>
</div>
