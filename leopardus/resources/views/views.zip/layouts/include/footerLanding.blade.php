<div class="col-12 p-0 mt-5 pt-3">
    {{-- <div class="card">
        <img src="{{asset('assets/imgLanding/trazado73.svg')}}" class="card-img">
        <div class="card-img-overlay d-flex justify-content-center align-items-center">
                <div class="row">
                    <div class="col-12">
                        <h3 class="text-blue-dark dark-font text-center">Lorem ipsu dolor</h3>
                        <p class="text-center text-white">
                            
                        </p>
                    </div>
                    <div class="col-12 mt-2">
                        <form class="form-inline d-flex justify-content-center">
                            <input type="email" class="form-control mb-2 mr-sm-2 rounded-alt" placeholder="Ingresa tu email">
                          
                            <button type="submit" class="btn btn-primary mb-2 rounded-alt bg-blue-alt pl-4 pr-4">Enviar</button>
                          </form>
                    </div>
                </div>
        </div>
    </div> --}}
            <div class="col-12 text-center pt-3 pb-3 bg-pink-alt text-white">
                &copy; {{date('Y')}} Cruzatel - Todos los derechos reservados - Desarrollado por <a class="text-white" href="https://valdusoft.com/">Valdusoft</a>
            </div>
</div>